"use strict";
exports.id = 6405;
exports.ids = [6405];
exports.modules = {

/***/ 3665:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8842);
/* harmony import */ var _pages_seller_components_DashboardTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5062);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const DashboardMainBoard = ()=>{
    const [totalCustomer, setTotalCustomer] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [totalSeller, setTotalSeller] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [totalBrand, setTotalBrand] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [totalInvoice, setTotalInvoice] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const getTotalBrands = async ()=>{
        const findTotalBrand = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__/* .getBrandList */ .Si)();
        setTotalBrand(findTotalBrand.length);
    };
    const getTotalCustomerSellerInvoice = async ()=>{
        const findTotalCustomer = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__/* .getCustomerSellerInvoiceCount */ .Ik)();
        setTotalCustomer(findTotalCustomer["totalCustomers"]);
        setTotalSeller(findTotalCustomer["totalSellers"]);
        setTotalInvoice(findTotalCustomer["totalOrders"]);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        getTotalBrands().then((r)=>true);
        getTotalCustomerSellerInvoice().then((r)=>true);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-3 col-md-6 col-sm-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            bgColor: "#FF9F43",
                            imageSrc: "fa-users",
                            altText: "Icon 1",
                            totalAmount: totalCustomer,
                            titleText: "Customers"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-3 col-md-6 col-sm-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            bgColor: "#00CFE8",
                            imageSrc: "fa-user",
                            altText: "Icon 1",
                            totalAmount: totalSeller,
                            titleText: "Sellers"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-3 col-md-6 col-sm-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            bgColor: "#1B2850",
                            imageSrc: "fa fa-city",
                            altText: "Icon 1",
                            totalAmount: totalBrand,
                            titleText: "Total Brand"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-3 col-md-6 col-sm-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                            bgColor: "#28C76F",
                            imageSrc: "fa-folder-open",
                            altText: "Icon 1",
                            totalAmount: totalInvoice,
                            titleText: "Total Invoice"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row p-3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_DashboardTable__WEBPACK_IMPORTED_MODULE_2__["default"], {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DashboardMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;