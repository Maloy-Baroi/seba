"use strict";
exports.id = 5194;
exports.ids = [5194];
exports.modules = {

/***/ 8982:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ onHandleCartLength),
/* harmony export */   "t": () => (/* binding */ callApi)
/* harmony export */ });
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2134);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__]);
isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// api.js

const API_BASE_URL = "https://seba-backend.xyz/";
const headers = {
    "Content-Type": "application/json"
};
function getAuthorizationHeader() {
    let accessToken = localStorage.getItem("access_token");
    if (accessToken) {
        return {
            "Authorization": `Bearer ${accessToken}`
        };
    }
    return {};
}
async function callApi(endpoint, options = {}) {
    const url = API_BASE_URL + endpoint;
    const requestOptions = {
        ...options,
        headers: {
            ...headers,
            ...getAuthorizationHeader(),
            ...options.headers
        }
    };
    const response = await (0,isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__["default"])(url, requestOptions);
    return await response.json();
}
const onHandleCartLength = async ()=>{
    var myHeaders = new Headers();
    myHeaders.append("Authorization", `Bearer ${localStorage.getItem("access_token")}`);
    var requestOptions = {
        method: "GET",
        headers: myHeaders,
        redirect: "follow"
    };
    const response = await (0,isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__["default"])("https://seba-backend.xyz/api-seller/cart-list/", requestOptions);
    return await response.json();
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5194:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$5": () => (/* binding */ getSellerList),
/* harmony export */   "AT": () => (/* binding */ getCategoryList),
/* harmony export */   "C9": () => (/* binding */ getOrderListForLoginUser),
/* harmony export */   "Cd": () => (/* binding */ getImportedProducts),
/* harmony export */   "HH": () => (/* binding */ getAlmostStockOutProducts),
/* harmony export */   "Ik": () => (/* binding */ getCustomerSellerInvoiceCount),
/* harmony export */   "LF": () => (/* binding */ getMostSoldProduct),
/* harmony export */   "MT": () => (/* binding */ getMedicineInfoList),
/* harmony export */   "Ns": () => (/* binding */ getCustomerReport),
/* harmony export */   "OP": () => (/* binding */ getShelfList),
/* harmony export */   "Oh": () => (/* binding */ getMedicineList),
/* harmony export */   "Si": () => (/* binding */ getBrandList),
/* harmony export */   "Wu": () => (/* binding */ getNearToExpiredDate),
/* harmony export */   "Yj": () => (/* binding */ getSubCategoryList),
/* harmony export */   "j3": () => (/* binding */ getProfileInfo),
/* harmony export */   "jw": () => (/* binding */ getProductList),
/* harmony export */   "ki": () => (/* binding */ getMonthlyTotalSales),
/* harmony export */   "qu": () => (/* binding */ getStockAlert),
/* harmony export */   "u2": () => (/* binding */ getPaymentMethodPercentage),
/* harmony export */   "vG": () => (/* binding */ getConsumptionTypeList),
/* harmony export */   "zk": () => (/* binding */ getAllOrders)
/* harmony export */ });
/* unused harmony exports getExpiredProductsList, getMonthSales */
/* harmony import */ var _apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8982);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_apis__WEBPACK_IMPORTED_MODULE_0__]);
_apis__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// example.js

async function getMedicineList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/medicine-list/");
}
async function getProductList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/products-list/");
}
async function getMedicineInfoList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/medicines-info/");
}
async function getExpiredProductsList() {
    return await callApi("api-product/expired-products/");
}
async function getCategoryList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/categories/");
}
async function getOrderListForLoginUser() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/order-list/");
}
async function getAllOrders() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-admin/order-list-for-manager/");
}
async function getCustomerReport() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/customer-report");
}
async function getSubCategoryList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/sub-categories/");
}
async function getConsumptionTypeList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/product-consumption-types/");
}
async function getBrandList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/brand/");
}
async function getShelfList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/all-shelf/");
}
async function getStockAlert() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/stock-alerts/");
}
async function getNearToExpiredDate() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/near-expiry-products/");
}
async function getAlmostStockOutProducts() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/stock-less-than-minimum-quantity/");
}
async function getCustomerSellerInvoiceCount() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-admin/customer-seller-order-count/");
}
async function getSellerList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-admin/seller-list/");
}
async function getProfileInfo() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/salesman-profile/");
}
async function getMonthSales() {
    return await callApi("api-seller/monthly-sales/");
}
async function getMonthlyTotalSales() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/order-stats/");
}
async function getPaymentMethodPercentage() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/payment-methods/");
}
async function getMostSoldProduct() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-seller/sold-products/");
}
async function getImportedProducts() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__/* .callApi */ .t)("api-product/imported-products/");
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;