"use strict";
exports.id = 4531;
exports.ids = [4531];
exports.modules = {

/***/ 4531:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_ProductsTable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1572);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3208);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pages_seller_components_ProductsTableForUpdate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(905);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_seller_components_ProductsTable__WEBPACK_IMPORTED_MODULE_1__, react_toastify__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_6__]);
([_pages_seller_components_ProductsTable__WEBPACK_IMPORTED_MODULE_1__, react_toastify__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const UpdateProductForm = ({ onHandleNotificationUpdate  })=>{
    const [productId, setProductId] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
    const [searchItem, setSearchItem] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [product_name, setProductName] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [quantity, setQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [alertQuantity, setAlertQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [sellingPrice, setSellingPrice] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [buyingPrice, setBuyingPrice] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [productExpiryDate, setProductExpiryDate] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [shelfNumber, setShelfNumber] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [allShelf, setAllShelf] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const [all_prods, setAllProds] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const [tableKey, setTableKey] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0);
    const onHandleSearchChange = (e)=>{
        setSearchItem(e.target.value);
    };
    const onStartUpdate = (pid, n, q, aq, sp, bp, shelf)=>{
        document.getElementById("updateFormCard").style.display = "block";
        setProductId(pid);
        setProductName(n);
        setQuantity(q);
        setAlertQuantity(aq);
        setSellingPrice(sp);
        setBuyingPrice(bp);
        setShelfNumber(shelf);
        setTableKey((prevKey)=>prevKey + 1);
    };
    const fetchData = async ()=>{
        const all_pro = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_6__/* .getProductList */ .jw)();
        setAllProds(all_pro);
    };
    const onHandleUpdateView = (e)=>{
        e.preventDefault();
        const requestBody = {
            quantity: quantity,
            minimum_alert_quantity: alertQuantity,
            minimum_selling_price: sellingPrice,
            expiry_date: productExpiryDate.toString(),
            shelf: shelfNumber,
            bought_price: buyingPrice
        };
        fetch(`https://seba-backend.xyz/api-product/update-product/${productId}/`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${localStorage.getItem("access_token")}`
            },
            body: JSON.stringify(requestBody)
        }).then((response)=>response.json()).then((data)=>{
            document.getElementById("updateFormCard").style.display = "none";
            setTableKey((prevKey)=>prevKey + 1);
            onHandleNotificationUpdate();
        }).catch((error)=>console.error(error));
    };
    const fetchShelves = async ()=>{
        const allShelves = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_6__/* .getShelfList */ .OP)();
        setAllShelf(allShelves);
    };
    const onHandleCloseUpdateForm = (e)=>{
        e.preventDefault();
        document.getElementById("updateFormCard").style.display = "none";
        setProductId("");
        setProductName("");
        setQuantity("");
        setAlertQuantity("");
        setSellingPrice("");
        setBuyingPrice("");
        setShelfNumber("");
        setProductExpiryDate("");
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        document.getElementById("updateFormCard").style.display = "none";
        fetchShelves().then((r)=>true);
        fetchData().then((r)=>true);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card ",
                id: "updateFormCard",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card-body",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: "form-group",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-11",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("legend", {
                                                className: "text-center",
                                                children: [
                                                    "Update Product Information",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                                                        style: {
                                                            fontSize: "13px"
                                                        },
                                                        children: [
                                                            "(",
                                                            product_name,
                                                            ")"
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                className: "btn btn-danger w-100",
                                                onClick: (e)=>onHandleCloseUpdateForm(e),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa fa-close"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 mb-2 mt-2",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Quantity"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        className: "form-control",
                                                        placeholder: "Quantity",
                                                        value: quantity,
                                                        onChange: (e)=>setQuantity(e.target.value)
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 mb-2 mt-2",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Minimum Alert Quantity"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        className: "form-control",
                                                        placeholder: "Minimum Alert Quantity",
                                                        value: alertQuantity,
                                                        onChange: (e)=>setAlertQuantity(e.target.value)
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 mb-2 mt-2",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Shelf Number"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                        className: "form-control",
                                                        value: shelfNumber,
                                                        onChange: (e)=>setShelfNumber(e.target.value),
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                children: "select shelf"
                                                            }),
                                                            allShelf && allShelf.map((shelf)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                                    children: [
                                                                        "Shelf: ",
                                                                        shelf.number,
                                                                        " Row: ",
                                                                        shelf.row,
                                                                        " Column: ",
                                                                        shelf.column
                                                                    ]
                                                                }, shelf.id))
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 mb-2 mt-2",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Selling Price"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        step: "0.01",
                                                        className: "form-control",
                                                        placeholder: "Selling Price",
                                                        value: sellingPrice,
                                                        onChange: (e)=>setSellingPrice(e.target.value)
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 mb-2 mt-2",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Buying Price"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        step: "0.01",
                                                        className: "form-control",
                                                        placeholder: "Buying Price",
                                                        value: buyingPrice,
                                                        onChange: (e)=>setBuyingPrice(e.target.value)
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 mb-2 mt-2",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-group",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        children: "Expiry Date"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "date",
                                                        step: "0.01",
                                                        className: "form-control",
                                                        placeholder: "Buying Price",
                                                        value: productExpiryDate,
                                                        onChange: (e)=>setProductExpiryDate(e.target.value)
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "row",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-group",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                className: "btn btn-warning text-white w-100",
                                                onClick: onHandleUpdateView,
                                                children: "Done"
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card mt-5",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card-body",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row mb-4",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-md-8",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            value: searchItem,
                                            onChange: onHandleSearchChange,
                                            className: (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default().searchInputField),
                                            placeholder: "search "
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "btn " + (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default().searchBtn),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                className: "fa fa-search"
                                            })
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProductsTableForUpdate__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                searchValue: searchItem,
                                onStartUpdate: onStartUpdate,
                                all_prods: all_prods
                            }, tableKey)
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UpdateProductForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;