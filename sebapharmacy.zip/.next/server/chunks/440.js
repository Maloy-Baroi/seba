"use strict";
exports.id = 440;
exports.ids = [440];
exports.modules = {

/***/ 440:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3208);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2410);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_seller_components_CreateMedicineForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1997);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__, _pages_seller_components_CreateMedicineForm__WEBPACK_IMPORTED_MODULE_4__]);
([_pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__, _pages_seller_components_CreateMedicineForm__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const CreateProductMainBoard = ()=>{
    const [medicineFormShow, setMedicineFormShow] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const onHandleFormChange = ()=>{
        console.log(medicineFormShow);
        setMedicineFormShow(!medicineFormShow);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    h4Text: "Product Add",
                    h6Text: "Create new product"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row mb-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-8"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 " + (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().extraWork),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    display: "inline-flex"
                                                },
                                                children: medicineFormShow ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        "Medicine \xa0",
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            className: (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().labelSwitch),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "checkbox",
                                                                    checked: medicineFormShow,
                                                                    onChange: onHandleFormChange
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: `${(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().checkboxSlider)} ${(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().checkboxRound)}`
                                                                })
                                                            ]
                                                        }),
                                                        "\xa0",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Others"
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                            children: "Medicine"
                                                        }),
                                                        " \xa0",
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            className: (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().labelSwitch),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "checkbox",
                                                                    checked: medicineFormShow,
                                                                    onChange: onHandleFormChange
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: `${(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().checkboxSlider)} ${(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_5___default().checkboxRound)}`
                                                                })
                                                            ]
                                                        }),
                                                        "\xa0 Others"
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: medicineFormShow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__["default"], {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_CreateMedicineForm__WEBPACK_IMPORTED_MODULE_4__["default"], {})
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateProductMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;