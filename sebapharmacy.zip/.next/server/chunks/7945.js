exports.id = 7945;
exports.ids = [7945];
exports.modules = {

/***/ 475:
/***/ ((module) => {

// Exports
module.exports = {
	"chartContainer": "LineChart_chartContainer__C0riX",
	"chart": "LineChart_chart__tetk7",
	"axis": "LineChart_axis__F2Rbe",
	"gridLine": "LineChart_gridLine__4yIXP",
	"line": "LineChart_line__4EHXm",
	"point": "LineChart_point__7AwKR",
	"label": "LineChart_label__r7obj"
};


/***/ }),

/***/ 7945:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_LineChart_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(475);
/* harmony import */ var _styles_LineChart_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_LineChart_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5194);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(738);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__]);
([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__, react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const LineChart = ()=>{
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const fetchMonthVsTotal = async ()=>{
        const allData = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getMonthlyTotalSales */ .ki)();
        setData(allData);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchMonthVsTotal().then((r)=>true);
    }, []);
    const chartData = {
        labels: data.map((item)=>item.month),
        datasets: [
            {
                label: "Total Sales",
                data: data.map((item)=>item.no_of_sales),
                backgroundColor: "rgba(75, 192, 192, 0.2)",
                borderColor: "rgba(75, 192, 192, 1)",
                borderWidth: 1
            }
        ]
    };
    const chartOptions = {
        responsive: true,
        scales: {
            x: {
                grid: {
                    display: false
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: "rgba(0, 0, 0, 0.1)",
                    borderColor: "rgba(0, 0, 0, 0.1)",
                    borderDash: [
                        5,
                        5
                    ]
                }
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_LineChart_module_css__WEBPACK_IMPORTED_MODULE_4___default().chartContainer),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_chartjs_2__WEBPACK_IMPORTED_MODULE_3__.Line, {
            data: chartData,
            options: chartOptions
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LineChart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;