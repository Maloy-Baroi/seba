"use strict";
exports.id = 6847;
exports.ids = [6847];
exports.modules = {

/***/ 6847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8842);
/* harmony import */ var _pages_seller_components_DashboardTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5062);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5194);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const DashboardMainBoard = ()=>{
    const [totalSellAmount, setTotalSellAmount] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0);
    const [totalCompletedOrder, setTotalCompletedOrder] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0);
    const [onCreditSell, setOnCreditSell] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0);
    const totalCompletedOrderAmount = async ()=>{
        const sellingQuantity = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getOrderListForLoginUser */ .C9)();
        let total = 0;
        let onCreditCount = 0;
        sellingQuantity.map((item)=>{
            total += parseInt(item.total_price);
            item.payment_method === "On Credit" ? onCreditCount++ : "";
        });
        setTotalSellAmount(total);
        setOnCreditSell(onCreditCount);
        setTotalCompletedOrder(sellingQuantity.length);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        totalCompletedOrderAmount().then((r)=>true);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "m-2 p-2",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-3 col-md-6 col-sm-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                bgColor: "#FF9F43",
                                imageSrc: "fa-briefcase",
                                altText: "Icon 1",
                                totalAmount: totalCompletedOrder,
                                titleText: "Total Completed Orders"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-3 col-md-6 col-sm-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                bgColor: "#00CFE8",
                                imageSrc: "fa-bangladeshi-taka-sign",
                                altText: "Icon 1",
                                totalAmount: totalSellAmount,
                                titleText: "Total Selling Amount"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-3 col-md-6 col-sm-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                bgColor: "#1B2850",
                                imageSrc: "fa fa-hand-holding-usd",
                                altText: "Icon 1",
                                totalAmount: onCreditSell,
                                titleText: "Total Sells on Credit"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-3 col-md-6 col-sm-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardCard__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                bgColor: "#28C76F",
                                imageSrc: "fa-star",
                                altText: "Icon 1",
                                totalAmount: "5",
                                titleText: "Your Average Performance"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row p-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_DashboardTable__WEBPACK_IMPORTED_MODULE_2__["default"], {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DashboardMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;