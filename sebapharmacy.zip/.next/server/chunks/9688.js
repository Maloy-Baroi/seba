exports.id = 9688;
exports.ids = [9688];
exports.modules = {

/***/ 2556:
/***/ ((module) => {

// Exports
module.exports = {
	"cartView": "sellBox_cartView__Jpsfj",
	"cartItem": "sellBox_cartItem__vnbGN",
	"itemDetails": "sellBox_itemDetails__17L16",
	"tabRow": "sellBox_tabRow__m82GQ",
	"totalContainer": "sellBox_totalContainer__eNMbs"
};


/***/ }),

/***/ 9688:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_sellBox_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2556);
/* harmony import */ var _styles_sellBox_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_sellBox_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const InvoiceTable = ()=>{
    const [orders, setOrders] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [searchItem, setSearchItem] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [user_type, setUserType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const navigator = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const fetchOrderData = async ()=>{
        const ordersList = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getOrderListForLoginUser */ .C9)();
        setOrders(ordersList);
    };
    const fetchAllOrderData = async ()=>{
        const orderList = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getAllOrders */ .zk)();
        setOrders(orderList);
    };
    function formatDate(date) {
        const options = {
            day: "numeric",
            month: "long",
            year: "numeric"
        };
        const day = ordinalSuffix(date.getDate());
        const formattedDate = date.toLocaleDateString(undefined, options);
        return `${formattedDate}`;
    }
    function ordinalSuffix(day) {
        if (day > 3 && day < 21) return `${day}th`;
        switch(day % 10){
            case 1:
                return `${day}st`;
            case 2:
                return `${day}nd`;
            case 3:
                return `${day}rd`;
            default:
                return `${day}th`;
        }
    }
    const handlePrint = (order_id)=>{
        navigator.push({
            pathname: `/seller/components/PageInvoice/`,
            query: {
                order_id: order_id
            }
        });
    };
    const filterOrder = orders.filter((order)=>order.id.toString().includes(searchItem));
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const userType = localStorage.getItem("group");
        setUserType(userType);
        if (userType === "manager") {
            fetchAllOrderData().then((r)=>true);
        } else {
            fetchOrderData().then((r)=>true);
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    className: "form-control mt-2 mb-3 w-50",
                    type: "text",
                    placeholder: "Search by Order ID",
                    value: searchItem,
                    onChange: (e)=>setSearchItem(e.target.value)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    style: {
                        backgroundColor: "rgba(254, 159, 67, 0.08)",
                        textAlign: "center",
                        paddingTop: "10px",
                        color: "#FF9F43"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-2",
                            children: "Order ID"
                        }),
                        user_type === "manager" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-2",
                                    children: "Date"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-2",
                                    children: "Customer"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-2",
                                    children: "Seller Name"
                                })
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-3",
                                    children: "Date"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-3",
                                    children: "Customer"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-3",
                            children: "Payment Method"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-1",
                            children: "Action"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                filterOrder ? filterOrder.map((item, index)=>{
                    const createdAtDate = new Date(item.created_at);
                    // Format the date
                    const formattedDate = formatDate(createdAtDate);
                    const formattedTime = createdAtDate.toLocaleTimeString([], {
                        hour: "numeric",
                        minute: "numeric"
                    });
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row text-center mb-2 mt-2 " + (_styles_sellBox_module_css__WEBPACK_IMPORTED_MODULE_4___default().tabRow),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-md-2",
                                children: [
                                    "sebaoid-",
                                    item.id
                                ]
                            }),
                            user_type === "manager" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-md-2",
                                        children: [
                                            formattedDate,
                                            ", ",
                                            formattedTime
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-2",
                                        children: item.get_customer_name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-2",
                                        children: item.get_seller_name
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-md-3",
                                        children: [
                                            formattedDate,
                                            ", ",
                                            formattedTime
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-3",
                                        children: item.get_customer_name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: item.payment_method
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn btn-danger",
                                    onClick: ()=>handlePrint(item.id),
                                    children: "Print"
                                })
                            })
                        ]
                    }, index);
                }) : ""
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InvoiceTable);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;