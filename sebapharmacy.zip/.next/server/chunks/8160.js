exports.id = 8160;
exports.ids = [8160];
exports.modules = {

/***/ 8081:
/***/ ((module) => {

// Exports
module.exports = {
	"chartContainer": "PieChart_chartContainer__BsdUC",
	"chart": "PieChart_chart__wj4xp",
	"label": "PieChart_label__gmiIR"
};


/***/ }),

/***/ 8160:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(738);
/* harmony import */ var _styles_PieChart_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8081);
/* harmony import */ var _styles_PieChart_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_PieChart_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__]);
([react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const PieChart = ()=>{
    // const data = [
    //     { label: "Cash", value: 50 },
    //     { label: "Bkash", value: 20 },
    //     { label: "On Credit", value: 30 },
    //     { label: "Credit Card", value: 10 },
    //     { label: "Debit Card", value: 15 },
    // ];
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const fetchPaymentMethodTotal = async ()=>{
        const allData = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getPaymentMethodPercentage */ .u2)();
        setData(allData);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchPaymentMethodTotal().then((r)=>true);
    }, []);
    const chartData = {
        labels: data.map((item)=>item.payment_method),
        datasets: [
            {
                data: data.map((item)=>item.total_orders),
                backgroundColor: [
                    "rgba(255,99,132,0.9)",
                    "rgba(255,159,64,0.9)",
                    "rgba(0, 0, 128, 0.9)",
                    "rgba(54, 162, 235, 0.9)",
                    "rgba(153, 102, 255, 0.9)",
                    "rgba(255, 0, 0, 0.9)",
                    "rgba(255, 255, 0, 0.9)",
                    "rgba(128, 0, 0, 0.9)",
                    "rgba(0, 255, 0, 0.9)",
                    "rgba(201, 203, 207, 0.9)",
                    "rgba(0, 128, 0, 0.9)",
                    "rgba(255,205,86,0.9)",
                    "rgba(75,192,192,0.9)",
                    "rgba(128, 128, 128, 0.9)",
                    "rgba(255, 165, 0, 0.9)",
                    "rgba(0, 0, 255, 0.9)",
                    "rgba(128, 128, 0, 0.9)",
                    "rgba(0, 128, 128, 0.9)",
                    "rgba(128, 0, 128, 0.9)",
                    "rgba(0, 0, 0, 0.9)"
                ],
                borderWidth: 0
            }
        ]
    };
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "right"
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_PieChart_module_css__WEBPACK_IMPORTED_MODULE_4___default().chartContainer),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__.Pie, {
            data: chartData,
            options: options,
            className: (_styles_PieChart_module_css__WEBPACK_IMPORTED_MODULE_4___default().chart)
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PieChart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;