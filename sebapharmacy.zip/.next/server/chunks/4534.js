exports.id = 4534;
exports.ids = [4534];
exports.modules = {

/***/ 6408:
/***/ ((module) => {

// Exports
module.exports = {
	"addButton": "addbutton_addButton__3kwLi"
};


/***/ }),

/***/ 5337:
/***/ ((module) => {

// Exports
module.exports = {
	"table": "productTable_table__dTGVH",
	"AddToSellBtn": "productTable_AddToSellBtn__M0aLM",
	"itemName": "productTable_itemName__kiGYo",
	"brandName": "productTable_brandName__s0uDS"
};


/***/ }),

/***/ 7776:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6408);
/* harmony import */ var _styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1__);


const AddButton = ({ buttonName , onHandleAddNew , btnWidth  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            className: "btn " + (_styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1___default().addButton),
            onClick: onHandleAddNew,
            style: {
                width: btnWidth
            },
            children: [
                buttonName,
                " \xa0",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "fa fa-arrow-right"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddButton);


/***/ }),

/***/ 4534:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3208);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2410);
/* harmony import */ var _styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5337);
/* harmony import */ var _styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5194);
/* harmony import */ var _pages_seller_components_AddNewHeaderInMainBoard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(956);
/* harmony import */ var _pages_manager_components_CustomToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7073);
/* harmony import */ var _pages_manager_components_AddButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7776);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__]);
([_pages_seller_components_CreateProductForm__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const CategoryMainBoard = ()=>{
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [searchItem, setSearchItem] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [formShow, setFormShow] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [catName, setCatName] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [toastShow, setToastShow] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const fetchCategories = async ()=>{
        const allCategories = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__/* .getCategoryList */ .AT)();
        setCategories(allCategories);
    };
    const onHandleShowForm = ()=>{
        setFormShow(!formShow);
    };
    function showToast() {
        setToastShow(!toastShow);
        setTimeout(()=>{
            setToastShow(false);
        }, 3000);
    }
    const onHandleAddNew = ()=>{
        const brandData = {
            name: catName
        };
        fetch("https://seba-backend.xyz/api-admin/create-categories/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("access_token") // Replace YOUR_TOKEN_HERE with the actual bearer token
            },
            body: JSON.stringify(brandData)
        }).then((response)=>response.json()).then((data)=>{
            console.log(data);
            showToast();
            onHandleShowForm();
            fetchCategories().then((r)=>true);
        }).catch((error)=>{
            console.error("Error creating brand:", error);
        // Handle the error
        });
    };
    const searchOption = (event)=>{
        const searchValue = event.target.value;
        setSearchItem(searchValue);
        if (searchValue && searchValue.length > 0) {
            const filteredCategories = categories.filter((cat)=>cat.name.toLowerCase().includes(searchValue.toLowerCase()));
            setCategories(filteredCategories);
        } else {
            fetchCategories().then((r)=>true);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        fetchCategories().then((r)=>true);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            toastShow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_manager_components_CustomToast__WEBPACK_IMPORTED_MODULE_6__["default"], {
                message: "Successfully Added!"
            }) : "",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_AddNewHeaderInMainBoard__WEBPACK_IMPORTED_MODULE_5__["default"], {
                header6Text: "List of Generic Names",
                header4Text: "Generic Name List",
                addingThing: "Add new category",
                onHandleShowForm: onHandleShowForm
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                style: formShow ? {
                    display: "block",
                    marginBottom: "20px"
                } : {
                    display: "none"
                },
                id: "categoryFormID",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                children: "Add New"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-10",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control mb-4",
                                        placeholder: "Generic Name",
                                        value: catName,
                                        onChange: (e)=>setCatName(e.target.value)
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-10",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_manager_components_AddButton__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                        btnWidth: "100%",
                                        buttonName: "Add",
                                        onHandleAddNew: onHandleAddNew
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row mb-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-8"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 " + (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_8___default().extraWork)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    value: searchItem,
                                    onChange: searchOption,
                                    className: "form-control w-50 mb-3",
                                    placeholder: "search "
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "card " + (_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_9___default().cardBackground),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "card-body",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                className: "card-title mb-4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                    children: "All Generic"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mt-3",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                    className: (_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_9___default().table),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                        scope: "col",
                                                                        children: "S.N."
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                        scope: "col",
                                                                        children: "Generic Name"
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                            children: categories && categories.length > 0 ? categories.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            "data-label": "S.N.",
                                                                            children: index + 1
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            "data-label": "Generic Name",
                                                                            children: item.name
                                                                        })
                                                                    ]
                                                                }, item.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {})
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;