exports.id = 3082;
exports.ids = [3082];
exports.modules = {

/***/ 9333:
/***/ ((module) => {

// Exports
module.exports = {
	"navContainer": "landing_navContainer__V_B1z",
	"container": "landing_container__0NI8r",
	"navUl": "landing_navUl__C_7Wg",
	"leftHandSide": "landing_leftHandSide__jlncE",
	"getStartedBtn": "landing_getStartedBtn__tNavb",
	"learnMoreBtn": "landing_learnMoreBtn__R9TC6",
	"rightHandSide": "landing_rightHandSide__eWbmz"
};


/***/ }),

/***/ 9498:
/***/ ((module) => {

// Exports
module.exports = {
	"navBrand": "logo_navBrand__oF4kM",
	"logoFirstSpan": "logo_logoFirstSpan__2gkwM"
};


/***/ }),

/***/ 3082:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ LandingPage)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/pages/component/landing.module.css
var landing_module = __webpack_require__(9333);
var landing_module_default = /*#__PURE__*/__webpack_require__.n(landing_module);
;// CONCATENATED MODULE: ./src/assets/image/landing_page_image/1_new.png
/* harmony default export */ const _1_new = ({"src":"/_next/static/media/1_new.cbc545d9.png","height":600,"width":800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAATlBMVEXM1NiBg4LNxsG2wsa5vMCMj5AnKCjGxMaqsrDX299RUlUwLS+5us0TGh4ECAve6e+Fvp9Oh2l1kZOTnJcNNzWxtbi/0NVzd3SnqanUmZtcvFUlAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANklEQVR4nAXBhwHAIAzAMAMhA+je/z9aiTpIV6mJ9ryCHRujN8nFV+KzO5sE2lVrmDNP5w6L/y68AcJTqMh+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/assets/image/landing_page_image/2_new.png
/* harmony default export */ const _2_new = ({"src":"/_next/static/media/2_new.7a6ee319.png","height":600,"width":800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAY1BMVEXh5+bMoITVcoXRv6bBnoHajqbX28Xnurfez8fUz8LHxbbOr5vEoHPgY57Ut7rPxdXixrzWpb3pu87h4NG6eHnFimfZuZrHt5HFmWW2sbHf4NjhY4Wzybjf2dLQyNDOnmzPiav9lE4qAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAOUlEQVR4nAXBhQGAMBAAsat+DYq77T8lCYQ8hgGIPvl5ug3WiejtLVhXO1nShYrtkdWjafpz3Yv5fjg3AmYIE05tAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/assets/image/landing_page_image/3_new.png
/* harmony default export */ const _3_new = ({"src":"/_next/static/media/3_new.43c7422e.png","height":600,"width":800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAQlBMVEW8rZbY0Me3q5vPzs3IxcK9uLbPyL+3sqvZ1tPQwrXBt5/YzcHIvrnUx8arm4Gxua5+dmq2r57R0cmIknSPgXTCt687hbY5AAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nAXBiQHAIAgAsQNBQO3f7r9qExTYNYLnGgMN58i7lzcjVpVkNt6vz7mZcUpKdV8/JYkBeOH3glgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/assets/image/landing_page_image/4_new.png
/* harmony default export */ const _4_new = ({"src":"/_next/static/media/4_new.c7b3fbd4.png","height":600,"width":800,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAMAAADJ2y/JAAAAUVBMVEWVlY6AOUB0aF9KISfCyMKOjYl8fHulp6JiXl1+XFWBRk2koZvHwLfg5uaZmJOrr66WenpKKiG0rqa5p5WBdnUiCQuIc26zppvTvbDa2M5+hYv+h56gAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAN0lEQVR4nAXBBwLAIAgAsVNRwNG9///QJjCpWJkViqlHGti6b10y2cNyP+Mjp1CvPhrHmaq/En8sZQHc/H6nrwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./src/pages/component/LogoManagement.js
var LogoManagement = __webpack_require__(1983);
;// CONCATENATED MODULE: ./src/pages/component/LandingPage.js









function LandingPage() {
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            style: {
                backgroundColor: "#ffffff"
            },
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("nav", {
                    className: "navbar navbar-expand-lg navbar-light bg-white",
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "container-fluid " + (landing_module_default()).navContainer,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                className: "navbar-brand",
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime.jsx(LogoManagement["default"], {})
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("button", {
                                className: "navbar-toggler",
                                type: "button",
                                "data-bs-toggle": "collapse",
                                "data-bs-target": "#navbarSupportedContent",
                                "aria-controls": "navbarSupportedContent",
                                "aria-expanded": "false",
                                "aria-label": "Toggle navigation",
                                children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                    className: "navbar-toggler-icon"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "collapse navbar-collapse",
                                id: "navbarSupportedContent",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                    className: "navbar-nav ms-auto mb-2 mb-lg-0 " + (landing_module_default()).navUl,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                className: "nav-link mt-2",
                                                href: "/",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    children: "New Features"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            className: "nav-item",
                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                className: "nav-link",
                                                href: "/login/",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                                    className: "btn " + (landing_module_default()).getStartedBtn,
                                                    children: "Get Started"
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: (landing_module_default()).container,
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-md-4",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: (landing_module_default()).leftHandSide,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h1", {
                                            children: "Inventory Management"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                                            children: "Seba pharmacy inventory management system is software that helps pharmacies keep track of their inventory levels, automate reordering, and generate detailed reports for better organization and efficiency."
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("button", {
                                            className: "btn " + (landing_module_default()).learnMoreBtn,
                                            "data-bs-toggle": "modal",
                                            "data-bs-target": "#exampleModal",
                                            children: "Learn To Use"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "modal fade",
                                            id: "exampleModal",
                                            tabIndex: "-1",
                                            "aria-labelledby": "exampleModalLabel",
                                            "aria-hidden": "true",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "modal-dialog modal-lg",
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "modal-content",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "modal-header text-center",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                                    className: "modal-title",
                                                                    id: "exampleModalLabel",
                                                                    children: "How to use"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("button", {
                                                                    type: "button",
                                                                    className: "btn-close",
                                                                    "data-bs-dismiss": "modal",
                                                                    "aria-label": "Close"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "modal-body",
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("video", {
                                                                controls: true,
                                                                style: {
                                                                    width: "100%"
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("source", {
                                                                        src: "/howtodoit.mp4",
                                                                        type: "video/mp4"
                                                                    }),
                                                                    "Your browser does not support the video tag."
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "modal-footer",
                                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("small", {
                                                                children: [
                                                                    "This website is a ",
                                                                    /*#__PURE__*/ jsx_runtime.jsx("b", {
                                                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                            href: "https://semsoftltd.com/",
                                                                            target: "_blank",
                                                                            children: "`SEMSOFT Limited`"
                                                                        })
                                                                    }),
                                                                    " product."
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-md-8 " + (landing_module_default()).rightHandSide,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    id: "carouselExampleControls",
                                    className: "carousel slide",
                                    "data-bs-ride": "carousel",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "carousel-inner",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "carousel-item active",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                        src: _1_new,
                                                        className: "d-block w-100",
                                                        alt: "..."
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "carousel-item",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                        src: _2_new,
                                                        className: "d-block w-100",
                                                        alt: "..."
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "carousel-item",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                        src: _3_new,
                                                        className: "d-block w-100",
                                                        alt: "..."
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "carousel-item",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                        src: _4_new,
                                                        className: "d-block w-100",
                                                        alt: "..."
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                            className: "carousel-control-prev",
                                            type: "button",
                                            "data-bs-target": "#carouselExampleControls",
                                            "data-bs-slide": "prev",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "carousel-control-prev-icon",
                                                    "aria-hidden": "true"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "visually-hidden",
                                                    children: "Previous"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                            className: "carousel-control-next",
                                            type: "button",
                                            "data-bs-target": "#carouselExampleControls",
                                            "data-bs-slide": "next",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "carousel-control-next-icon",
                                                    "aria-hidden": "true"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "visually-hidden",
                                                    children: "Next"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 1983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_component_logo_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9498);
/* harmony import */ var _pages_component_logo_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_pages_component_logo_module_css__WEBPACK_IMPORTED_MODULE_1__);


const LogoManagement = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_pages_component_logo_module_css__WEBPACK_IMPORTED_MODULE_1___default().navBrand),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_pages_component_logo_module_css__WEBPACK_IMPORTED_MODULE_1___default().logoFirstSpan),
                        children: "Seba"
                    }),
                    "\xa0",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_pages_component_logo_module_css__WEBPACK_IMPORTED_MODULE_1___default().logoSecondSpan),
                        children: "Pharmacy"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoManagement);


/***/ })

};
;