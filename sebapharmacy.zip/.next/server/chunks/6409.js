"use strict";
exports.id = 6409;
exports.ids = [6409];
exports.modules = {

/***/ 6409:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9081);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_profileFormInputComp_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9561);
/* harmony import */ var _styles_profileFormInputComp_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_profileFormInputComp_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const SellerProfileForm = ()=>{
    const [nid, setNId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [photo, setPhoto] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const [frontPageNId, setFrontPageNId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const [backPageNId, setBackPageNId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const [permanentAddress, setPermanentAddress] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [presentAddress, setPresentAddress] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [salary, setSalary] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [personal_contact, setPersonalContact] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [emergency_contact, setEmergencyContact] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const onHandlePostForm = ()=>{
        var myHeaders = new Headers();
        myHeaders.append("Authorization", "Bearer " + localStorage.getItem("access_token"));
        var formdata = new FormData();
        formdata.append("nid", nid);
        formdata.append("photo", photo);
        formdata.append("NID_front_photo", frontPageNId);
        formdata.append("NID_back_photo", backPageNId);
        formdata.append("permanent_address", permanentAddress);
        formdata.append("present_address", presentAddress);
        formdata.append("salary", "0");
        formdata.append("personal_contact", personal_contact);
        formdata.append("emergency_contact", emergency_contact);
        formdata.append("is_active", true);
        var requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: formdata,
            redirect: "follow"
        };
        fetch("https://seba-backend.xyz/api-seller/salesman-profile-create/", requestOptions).then((response)=>response.text()).then((result)=>console.log(result)).catch((error)=>console.log("error", error));
    };
    const onFetchSellerInfo = async ()=>{
        const sellerProfile = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_4__/* .getProfileInfo */ .j3)();
        setNId(sellerProfile["nid"]);
        setPersonalContact(sellerProfile["personal_contact"]);
        setEmergencyContact(sellerProfile["emergency_contact"]);
        setPermanentAddress(sellerProfile["permanent_address"]);
        setPresentAddress(sellerProfile["present_address"]);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        onFetchSellerInfo().then((r)=>true);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                nid.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                inputType: "text",
                                labelText: "National Identity Number (Unchangeable)",
                                placeholderText: nid,
                                disablePositive: true
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                inputType: "text",
                                labelText: "Personal Phone (Unchangeable)",
                                placeholderText: personal_contact,
                                disablePositive: true
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                inputType: "text",
                                labelText: "Emergency Contact (Unchangeable)",
                                placeholderText: emergency_contact,
                                disablePositive: true
                            })
                        })
                    ]
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                inputType: "text",
                                labelText: "National Identity Number",
                                placeholderText: "Enter NId number",
                                requiredPositive: true,
                                onInputChange: setNId
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                inputType: "text",
                                labelText: "Personal Phone",
                                placeholderText: "Enter phone number",
                                requiredPositive: true,
                                onInputChange: setPersonalContact
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                inputType: "text",
                                labelText: "Emergency Contact",
                                placeholderText: "Enter phone number",
                                requiredPositive: true,
                                onInputChange: setEmergencyContact
                            })
                        })
                    ]
                }),
                permanentAddress.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row mt-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-6",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                labelText: "Permanent Address (Unchangeable)",
                                inputType: "text",
                                placeholderText: permanentAddress,
                                disablePositive: true,
                                inputValue: permanentAddress
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-6",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                labelText: "Present Address",
                                inputType: "text",
                                requiredPositive: true,
                                placeholderText: "Enter Address",
                                onInputChange: setPresentAddress,
                                inputValue: presentAddress
                            })
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-md-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        labelText: "Permanent Address",
                        inputType: "text",
                        requiredPositive: true,
                        placeholderText: "Enter Address",
                        onInputChange: setPermanentAddress
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row mt-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                labelText: "NId Front Page Photo",
                                placeholderText: "",
                                requiredPositive: true,
                                inputType: "file",
                                onInputChange: setFrontPageNId
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                labelText: "NId Back Page Photo",
                                placeholderText: "",
                                requiredPositive: true,
                                inputType: "file",
                                onInputChange: setBackPageNId
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-4",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ProfileFormInputComp__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                labelText: "Profile Picture",
                                inputType: "file",
                                placeholderText: "",
                                requiredPositive: true,
                                onInputChange: setPhoto
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-lg-12",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn me-2 " + (_styles_profileFormInputComp_module_css__WEBPACK_IMPORTED_MODULE_5___default().btnSubmit),
                                onClick: onHandlePostForm,
                                children: "Submit"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn " + (_styles_profileFormInputComp_module_css__WEBPACK_IMPORTED_MODULE_5___default().btnCancel),
                                children: "Cancel"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SellerProfileForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;