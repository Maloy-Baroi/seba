exports.id = 2104;
exports.ids = [2104];
exports.modules = {

/***/ 3208:
/***/ ((module) => {

// Exports
module.exports = {
	"pageHeader": "productsPage_pageHeader__fgVU0",
	"searchInputField": "productsPage_searchInputField__GYG0a",
	"searchBtn": "productsPage_searchBtn__EzDW4",
	"extraWork": "productsPage_extraWork__MrCdz",
	"labelSwitch": "productsPage_labelSwitch__KghL2",
	"checkboxSlider": "productsPage_checkboxSlider__WY81L",
	"checkboxRound": "productsPage_checkboxRound__FkloV"
};


/***/ }),

/***/ 2104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3208);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_1__);


const MainboardHead = ({ h4Text , h6Text  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_1___default().pageHeader),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    children: h4Text
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                    children: h6Text
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainboardHead);


/***/ })

};
;