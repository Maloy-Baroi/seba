"use strict";
exports.id = 6218;
exports.ids = [6218];
exports.modules = {

/***/ 6218:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(738);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__]);
([react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__, _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const TopSoldProductHorizontalBar = ()=>{
    const [soldProducts, setSoldProducts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const fetchMostSoldProduct = async ()=>{
        const allSoldProduct = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getMostSoldProduct */ .LF)();
        setSoldProducts(allSoldProduct);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchMostSoldProduct().then((r)=>true);
        const backgroundColors = [
            "rgba(255, 99, 132, 0.2)",
            "rgba(255, 159, 64, 0.2)",
            "rgba(255, 205, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(201, 203, 207, 0.2)",
            "rgba(128, 0, 0, 0.2)",
            "rgba(255, 0, 0, 0.2)",
            "rgba(255, 255, 0, 0.2)",
            "rgba(0, 128, 0, 0.2)",
            "rgba(0, 255, 0, 0.2)",
            "rgba(0, 0, 128, 0.2)",
            "rgba(0, 0, 255, 0.2)",
            "rgba(128, 128, 128, 0.2)",
            "rgba(255, 165, 0, 0.2)",
            "rgba(128, 128, 0, 0.2)",
            "rgba(0, 128, 128, 0.2)",
            "rgba(128, 0, 128, 0.2)",
            "rgba(0, 0, 0, 0.2)"
        ];
    }, []);
    const getChartLabels = ()=>soldProducts.map((product)=>product.name);
    const getChartData = ()=>soldProducts.map((product)=>product.numbers);
    const data = {
        labels: getChartLabels(),
        datasets: [
            {
                label: "Number of Sales",
                data: getChartData(),
                backgroundColor: [
                    "rgba(255,99,132,0.32)",
                    "rgba(255,159,64,0.32)",
                    "rgba(255,205,86,0.32)",
                    "rgba(75,192,192,0.32)",
                    "rgba(54, 162, 235, 0.32)",
                    "rgba(153, 102, 255, 0.32)",
                    "rgba(201, 203, 207, 0.32)",
                    "rgba(128, 0, 0, 0.32)",
                    "rgba(255, 0, 0, 0.32)",
                    "rgba(255, 255, 0, 0.32)",
                    "rgba(0, 128, 0, 0.32)",
                    "rgba(0, 255, 0, 0.32)",
                    "rgba(0, 0, 128, 0.32)",
                    "rgba(0, 0, 255, 0.32)",
                    "rgba(128, 128, 128, 0.32)",
                    "rgba(255, 165, 0, 0.32)",
                    "rgba(128, 128, 0, 0.32)",
                    "rgba(0, 128, 128, 0.32)",
                    "rgba(128, 0, 128, 0.32)",
                    "rgba(0, 0, 0, 0.32)"
                ],
                borderColor: [
                    "rgb(255, 99, 132)",
                    "rgb(255, 159, 64)",
                    "rgb(255, 205, 86)",
                    "rgb(75, 192, 192)",
                    "rgb(54, 162, 235)",
                    "rgb(153, 102, 255)",
                    "rgb(201, 203, 207)"
                ],
                borderWidth: 1
            }
        ]
    };
    const options = {
        indexAxis: "y",
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                type: "linear",
                beginAtZero: true,
                stepSize: 1,
                ticks: {
                    precision: 0
                }
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_chartjs_2__WEBPACK_IMPORTED_MODULE_2__.Bar, {
            data: data,
            options: options
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopSoldProductHorizontalBar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;