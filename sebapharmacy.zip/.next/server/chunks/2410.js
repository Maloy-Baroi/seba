exports.id = 2410;
exports.ids = [2410];
exports.modules = {

/***/ 871:
/***/ ((module) => {

// Exports
module.exports = {
	"formGroup": "productForm_formGroup__6GScq",
	"btnSubmit": "productForm_btnSubmit___D4EX"
};


/***/ }),

/***/ 2410:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5194);
/* harmony import */ var _styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(871);
/* harmony import */ var _styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const CreateProductForm = ()=>{
    const [barcode, setBarcode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [p_name, setPName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [p_type, setPType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [strength, setStrength] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [allConsumptionType, setAllConsumptionType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [purchased_quantity, setPurchasedQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [minimumQuantity, setMinimumQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [minimumPrice, setMinimumPrice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [buyingPrice, setBuyingPrice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [expiry_date, setExpiryDate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [shelfNumber, setShelfNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [description_, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [subCategories, setSubCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [allBrand, setBrand] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [allShelf, setAllShelf] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [categorySearchText, setCategorySearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [subCategorySearchText, setSubCategorySearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [brandSearchText, setBrandSearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [imported, setImported] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [importer, setImporter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const navigator = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchShelves = async ()=>{
            const allShelves = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getShelfList */ .OP)();
            setAllShelf(allShelves);
        };
        fetchShelves().then((r)=>true);
    }, []);
    const onHandleSubmitForm = (e)=>{
        e.preventDefault();
        // const formData = new FormData(e.target)
        const requestBody = {
            barcode_id: barcode,
            name: p_name,
            type: p_type,
            unit: strength,
            quantity: purchased_quantity,
            minimum_alert_quantity: minimumQuantity,
            minimum_selling_price: minimumPrice,
            expiry_date: expiry_date.toString(),
            shelf: shelfNumber,
            status: status,
            category: categorySearchText,
            sub_category: subCategorySearchText,
            brand: brandSearchText,
            bought_price: buyingPrice,
            description: description_ ? description_ : "No details",
            is_medicine: false
        };
        if (imported) {
            requestBody.importer = importer;
            requestBody.imported = true;
        }
        fetch("https://seba-backend.xyz/api-product/products-list/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${localStorage.getItem("access_token")}`
            },
            body: JSON.stringify(requestBody)
        }).then((response)=>response.json()).then((data)=>navigator.push("seller/products")).catch((error)=>console.error(error));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "card",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "card-body",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                children: "Add Product"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                            children: [
                                                "Product Barcode",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-danger",
                                                    children: " *"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: barcode,
                                            onChange: (e)=>setBarcode(e.target.value),
                                            placeholder: "Product Barcode"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-1"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-md-4",
                                style: {
                                    marginTop: "40px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "checkbox",
                                        value: imported,
                                        onClick: (e)=>setImported(!imported),
                                        style: {
                                            width: "50px"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "\xa0 Imported?"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "row",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-12",
                                        children: imported && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Importer"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "text",
                                                    className: "form-control",
                                                    value: importer,
                                                    placeholder: "Importer Company Name",
                                                    onChange: (event)=>setImporter(event.target.value)
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-1"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Product Name*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: p_name,
                                            onChange: (e)=>setPName(e.target.value),
                                            placeholder: "Product Name"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Category Name *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: categorySearchText,
                                            onChange: (e)=>setCategorySearchText(e.target.value),
                                            placeholder: "Cosmetics/Food"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "For *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: subCategorySearchText,
                                            onChange: (e)=>setSubCategorySearchText(e.target.value),
                                            placeholder: "Men/Women/Baby"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Brand Name *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: brandSearchText,
                                            onChange: (e)=>setBrandSearchText(e.target.value),
                                            placeholder: "Brand"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Type *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: p_type,
                                            onChange: (e)=>setPType(e.target.value),
                                            placeholder: "Consumption type"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Weight *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Example: 250g/250ml",
                                            value: strength,
                                            onChange: (e)=>setStrength(e.target.value)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Quantity *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Quantity",
                                            value: purchased_quantity.toString(),
                                            onChange: (e)=>setPurchasedQuantity(parseInt(e.target.value))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Minimum Alert Qty*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Minimum Qty",
                                            value: minimumQuantity.toString(),
                                            onChange: (e)=>setMinimumQuantity(parseInt(e.target.value))
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Minimum Selling Price *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Price",
                                            min: "0.25",
                                            step: "0.01",
                                            value: minimumPrice.toString(),
                                            onChange: (e)=>setMinimumPrice(parseFloat(e.target.value))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Buying Price *"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Price",
                                            min: "0.25",
                                            step: "0.01",
                                            value: buyingPrice.toString(),
                                            onChange: (e)=>setBuyingPrice(parseFloat(e.target.value))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Expiry Date*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "date",
                                            className: "form-control",
                                            value: expiry_date,
                                            onChange: (event)=>setExpiryDate(event.target.value)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Shelf*"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                            className: "form-control",
                                            value: shelfNumber,
                                            onChange: (e)=>setShelfNumber(e.target.value),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    children: "select shelf"
                                                }),
                                                allShelf && allShelf.length > 0 ? allShelf.map((shelf)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                        children: [
                                                            "Shelf: ",
                                                            shelf.number,
                                                            " Row: ",
                                                            shelf.row,
                                                            " Column: ",
                                                            shelf.column
                                                        ]
                                                    }, shelf.id)) : ""
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-12 col-md-12 col-sm-12",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        className: "form-control",
                                        value: description_,
                                        onChange: (e)=>setDescription(e.target.value)
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn me-2 " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().btnSubmit),
                                onClick: onHandleSubmitForm,
                                children: "Submit"
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateProductForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;