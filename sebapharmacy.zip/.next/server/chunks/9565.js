exports.id = 9565;
exports.ids = [9565];
exports.modules = {

/***/ 5337:
/***/ ((module) => {

// Exports
module.exports = {
	"table": "productTable_table__dTGVH",
	"AddToSellBtn": "productTable_AddToSellBtn__M0aLM",
	"itemName": "productTable_itemName__kiGYo",
	"brandName": "productTable_brandName__s0uDS"
};


/***/ }),

/***/ 9565:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5337);
/* harmony import */ var _styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ProductsTable = ({ searchValue  })=>{
    const [products, setProducts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const searchOption = ()=>{
        const filteredProducts = products.filter((product)=>product.name.toLowerCase().includes(searchValue.toLowerCase()) || product.category.toLowerCase().includes(searchValue.toLowerCase()));
        setProducts(filteredProducts);
    };
    const fetchImportedProducts = async ()=>{
        const allImported = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getImportedProducts */ .Cd)();
        setProducts(allImported);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (searchValue) {
            searchOption();
        } else {
            fetchImportedProducts().then((r)=>true);
        }
    }, [
        searchValue
    ]);
    const onHandle = (id)=>{
        let quantity = parseInt(prompt("Quantity?: "));
        const sellcard = JSON.parse(localStorage.getItem("sellcard") || "[]");
        const item = {
            id,
            quantity
        };
        const existProduct = sellcard.find((product)=>product.id === id);
        if (existProduct) {
            existProduct.quantity = parseInt(existProduct.quantity) + quantity;
            localStorage.setItem("sellcard", JSON.stringify(sellcard));
        } else {
            sellcard.push(item);
            localStorage.setItem("sellcard", JSON.stringify(sellcard));
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "card " + (_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3___default().cardBackground),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "card-body",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        className: "card-title mb-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                            children: "All Products"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                            className: (_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3___default().table),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                children: "Name"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                children: "Generic"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                children: "Quantity Left"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                children: "Shelf"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                children: "Expiry Date"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                scope: "col",
                                                children: "Price"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                    children: products ? products.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    "data-label": "Name",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: (_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3___default().itemName),
                                                            children: [
                                                                item.name,
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            children: [
                                                                "(",
                                                                item.unit,
                                                                ")"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                            className: (_styles_productTable_module_css__WEBPACK_IMPORTED_MODULE_3___default().brandName),
                                                            children: [
                                                                "(",
                                                                item.brand,
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    "data-label": "Generic",
                                                    style: {
                                                        width: "148px",
                                                        whiteSpace: "pre-wrap"
                                                    },
                                                    children: item.category
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    "data-label": "Quantity Left",
                                                    children: item.quantity
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                    "data-label": "Brand",
                                                    children: [
                                                        "Shelf: ",
                                                        item.shelf.split(", ")[0],
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        "Row: ",
                                                        item.shelf.split(", ")[1],
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                        "Column: ",
                                                        item.shelf.split(", ")[2]
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    "data-label": "Expiry Date",
                                                    children: item.expiry_date
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    "data-label": "Price",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("b", {
                                                        children: [
                                                            "৳ ",
                                                            item.minimum_selling_price
                                                        ]
                                                    })
                                                })
                                            ]
                                        }, item.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {})
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsTable);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;