exports.id = 1374;
exports.ids = [1374];
exports.modules = {

/***/ 6408:
/***/ ((module) => {

// Exports
module.exports = {
	"addButton": "addbutton_addButton__3kwLi"
};


/***/ }),

/***/ 8101:
/***/ ((module) => {

// Exports
module.exports = {
	"table": "shelfPage_table__2Hb1X",
	"tableRowEven": "shelfPage_tableRowEven__2esvx",
	"tableRowOdd": "shelfPage_tableRowOdd__u0PeQ"
};


/***/ }),

/***/ 7776:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6408);
/* harmony import */ var _styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1__);


const AddButton = ({ buttonName , onHandleAddNew , btnWidth  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            className: "btn " + (_styles_addbutton_module_css__WEBPACK_IMPORTED_MODULE_1___default().addButton),
            onClick: onHandleAddNew,
            style: {
                width: btnWidth
            },
            children: [
                buttonName,
                " \xa0",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "fa fa-arrow-right"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddButton);


/***/ }),

/***/ 1374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3208);
/* harmony import */ var _styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_shelfPage_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8101);
/* harmony import */ var _styles_shelfPage_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_shelfPage_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5194);
/* harmony import */ var _pages_seller_components_AddNewHeaderInMainBoard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(956);
/* harmony import */ var _pages_manager_components_AddButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7776);
/* harmony import */ var _pages_manager_components_CustomToast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7073);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const ShelfMainBoard = ()=>{
    const [shelvesList, setShelvesList] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [formShow, setFormShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [shelfNo, setShelfNo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [rowNo, setRowNo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [colNo, setColNo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [toastShow, setToastShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const onHandleShowForm = ()=>{
        setFormShow(!formShow);
    };
    function showToast() {
        setToastShow(!toastShow);
        setTimeout(()=>{
            setToastShow(false);
        }, 3000);
    }
    const onHandleAddNew = ()=>{
        const brandData = {
            number: shelfNo,
            row: rowNo,
            column: colNo
        };
        fetch("https://seba-backend.xyz/api-admin/create-shelves/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("access_token") // Replace YOUR_TOKEN_HERE with the actual bearer token
            },
            body: JSON.stringify(brandData)
        }).then((response)=>response.json()).then((data)=>{
            console.log(data);
            showToast();
            onHandleShowForm();
            fetchShelfList().then((r)=>true);
        }).catch((error)=>{
            console.error("Error creating brand:", error);
        // Handle the error
        });
    };
    const fetchShelfList = ()=>{
        (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getShelfList */ .OP)().then((r)=>{
            setShelvesList(r);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchShelfList();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            toastShow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_manager_components_CustomToast__WEBPACK_IMPORTED_MODULE_6__["default"], {
                message: "Successfully Added!"
            }) : "",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_AddNewHeaderInMainBoard__WEBPACK_IMPORTED_MODULE_4__["default"], {
                header4Text: "Shelves",
                header6Text: "Manage all the shelves",
                addingThing: "Shelf",
                onHandleShowForm: onHandleShowForm
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                style: formShow ? {
                    display: "block",
                    marginBottom: "20px"
                } : {
                    display: "none"
                },
                id: "companyFormID",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                children: "Add New"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Shelf No.",
                                            value: shelfNo,
                                            onChange: (e)=>setShelfNo(e.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Row No.",
                                            value: rowNo,
                                            onChange: (e)=>setRowNo(e.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Column No.",
                                            value: colNo,
                                            onChange: (e)=>setColNo(e.target.value)
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row mt-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_manager_components_AddButton__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                        btnWidth: "100%",
                                        buttonName: "Add",
                                        onHandleAddNew: onHandleAddNew
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row mb-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-8"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 " + (_styles_productsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default().extraWork)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    className: (_styles_shelfPage_module_css__WEBPACK_IMPORTED_MODULE_8___default().table),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "col",
                                                        children: "S.N."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "col",
                                                        children: "Shelf No."
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "col",
                                                        children: "Row"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "col",
                                                        children: "Column"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                            children: shelvesList.length > 0 ? shelvesList.map((shelf, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    style: index % 2 === 0 ? {
                                                        backgroundColor: "rgba(255, 159," + index + 10 + ", 0.78)"
                                                    } : {
                                                        backgroundColor: "rgba(255, 159," + index + 15 + ", 0.78)"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            "data-label": "S.N.",
                                                            children: index
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            "data-label": "Shelf",
                                                            children: shelf.number
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            "data-label": "Row",
                                                            children: shelf.row
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            "data-label": "Column",
                                                            children: shelf.column
                                                        })
                                                    ]
                                                }, shelf.id)) : ""
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShelfMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;