"use strict";
exports.id = 9797;
exports.ids = [9797];
exports.modules = {

/***/ 239:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var _pages_seller_components_InvoiceTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9688);
/* harmony import */ var _pages_seller_inventory_report__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1962);
/* harmony import */ var _pages_seller_components_ExpiryProductReportTable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5133);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _pages_seller_components_StockFinishedProduct__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1136);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_seller_components_InvoiceTable__WEBPACK_IMPORTED_MODULE_2__, _pages_seller_inventory_report__WEBPACK_IMPORTED_MODULE_3__, _pages_seller_components_ExpiryProductReportTable__WEBPACK_IMPORTED_MODULE_4__, _pages_seller_components_StockFinishedProduct__WEBPACK_IMPORTED_MODULE_6__]);
([_pages_seller_components_InvoiceTable__WEBPACK_IMPORTED_MODULE_2__, _pages_seller_inventory_report__WEBPACK_IMPORTED_MODULE_3__, _pages_seller_components_ExpiryProductReportTable__WEBPACK_IMPORTED_MODULE_4__, _pages_seller_components_StockFinishedProduct__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const InventoryReportMainBoard = ()=>{
    const [showWhat, setShowWhat] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    const [buttonText, setButtonText] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("Almost Stock-out");
    const onHandleProductCategoryChange = ()=>{
        if (buttonText === "About to Expire") {
            setButtonText("Almost Stock-out");
        } else {
            setButtonText("About to Expire");
        }
        setShowWhat(!showWhat);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    h4Text: "Inventory Report",
                    h6Text: "Stock Management"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-md-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row mb-5 mt-5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-6",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "btn btn-danger",
                                                onClick: onHandleProductCategoryChange,
                                                children: buttonText
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: showWhat ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_ExpiryProductReportTable__WEBPACK_IMPORTED_MODULE_4__["default"], {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_StockFinishedProduct__WEBPACK_IMPORTED_MODULE_6__["default"], {})
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InventoryReportMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8939:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


const OnlyHead = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("title", {
                children: [
                    "Seba Pharmacy | Seller | ",
                    props.page
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OnlyHead);


/***/ }),

/***/ 1962:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_OnlyHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8939);
/* harmony import */ var _pages_seller_components_DashboardNavbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7780);
/* harmony import */ var _styles_dashboard_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4373);
/* harmony import */ var _styles_dashboard_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_dashboard_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _pages_seller_components_Sidebar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8540);
/* harmony import */ var _pages_seller_components_InvoiceReportMainBoard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(803);
/* harmony import */ var _pages_seller_components_InventoryReportMainBoard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(239);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_seller_components_DashboardNavbar__WEBPACK_IMPORTED_MODULE_2__, _pages_seller_components_Sidebar__WEBPACK_IMPORTED_MODULE_3__, _pages_seller_components_InvoiceReportMainBoard__WEBPACK_IMPORTED_MODULE_4__, _pages_seller_components_InventoryReportMainBoard__WEBPACK_IMPORTED_MODULE_5__]);
([_pages_seller_components_DashboardNavbar__WEBPACK_IMPORTED_MODULE_2__, _pages_seller_components_Sidebar__WEBPACK_IMPORTED_MODULE_3__, _pages_seller_components_InvoiceReportMainBoard__WEBPACK_IMPORTED_MODULE_4__, _pages_seller_components_InventoryReportMainBoard__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const InventoryReport = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_OnlyHead__WEBPACK_IMPORTED_MODULE_1__["default"], {
                page: "Invoice Report"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_DashboardNavbar__WEBPACK_IMPORTED_MODULE_2__["default"], {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row w-100",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-2 " + (_styles_dashboard_module_css__WEBPACK_IMPORTED_MODULE_6___default().sidebarContainer),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_Sidebar__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                    activeState: "inventory-report"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-10",
                                style: {
                                    backgroundColor: "#f8f8f8"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_dashboard_module_css__WEBPACK_IMPORTED_MODULE_6___default().content),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_InventoryReportMainBoard__WEBPACK_IMPORTED_MODULE_5__["default"], {})
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InventoryReport);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;