"use strict";
exports.id = 844;
exports.ids = [844];
exports.modules = {

/***/ 844:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const PurchaseReportMainBoard = ()=>{
    const [purchasedProducts, setPurchasedProducts] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [startDate, setStartDate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [endDate, setEndDate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const fetchPurchasedProduct = async ()=>{
        var myHeaders = new Headers();
        myHeaders.append("Authorization", `Bearer ${localStorage.getItem("access_token")}`);
        var requestOptions = {
            method: "GET",
            headers: myHeaders,
            redirect: "follow"
        };
        fetch("https://seba-backend.xyz/api-seller/purchased-products/", requestOptions).then((response)=>response.json()).then((result)=>{
            console.log(result);
            setPurchasedProducts(result);
        }).catch((error)=>console.log("error", error));
    };
    function formatDate(datetimeString) {
        const options = {
            year: "numeric",
            month: "long",
            day: "numeric"
        };
        const datetime = new Date(datetimeString);
        return datetime.toLocaleDateString("en-US", options);
    }
    const handleFilter = ()=>{
        const startDateObj = new Date(startDate);
        const endDateObj = new Date(endDate);
        // Filter products based on selected date range
        const filteredProducts = purchasedProducts.filter((item)=>{
            const productDate = new Date(item.updated_at); // Adjust to the actual date field in your data
            // Check if productDate falls within the selected date range
            return productDate >= startDateObj && productDate <= endDateObj;
        });
        // Set the filtered products
        console.log("filtered Item: ", filteredProducts);
        setPurchasedProducts(filteredProducts);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchPurchasedProduct().then((r)=>console.log(r));
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    h4Text: "Stock Product List",
                    h6Text: "Manage shop products"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-6 mt-2 mb-2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "Start Date:"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "date",
                                                    className: "form-control",
                                                    value: startDate,
                                                    onChange: (e)=>setStartDate(e.target.value)
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-6 mt-2 mb-2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-group",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: "End Date:"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "date",
                                                    className: "form-control",
                                                    value: endDate,
                                                    onChange: (e)=>setEndDate(e.target.value)
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "bt mb-5 w-100",
                                onClick: handleFilter,
                                style: {
                                    backgroundColor: "rgb(255, 159, 67)",
                                    border: "none",
                                    borderRadius: "5px",
                                    height: "36px",
                                    color: "#505050",
                                    fontWeight: "600"
                                },
                                children: "Filter"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "row",
                                children: purchasedProducts.length > 0 ? purchasedProducts.map((item)=>{
                                    const dateToShow = item.updated_at > item.created_at ? item.updated_at : item.created_at;
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-4 p-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "card",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "card-body",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                                                        className: "card-title",
                                                        children: [
                                                            item.name,
                                                            " (",
                                                            item.unit,
                                                            ")"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "card-text",
                                                        children: item.category
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "card-text",
                                                        children: [
                                                            "Price: ৳ ",
                                                            item.minimum_selling_price
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "btn w-100",
                                                        style: {
                                                            backgroundColor: "#FF9F43",
                                                            border: "none",
                                                            cursor: "not-allowed"
                                                        },
                                                        children: formatDate(dateToShow)
                                                    })
                                                ]
                                            })
                                        })
                                    }, item.id);
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "No Product Found"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PurchaseReportMainBoard);


/***/ })

};
;