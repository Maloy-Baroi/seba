"use strict";
exports.id = 9609;
exports.ids = [9609];
exports.modules = {

/***/ 9609:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var _styles_BrandsPage_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8264);
/* harmony import */ var _styles_BrandsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_styles_BrandsPage_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_brandTable_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5587);
/* harmony import */ var _styles_brandTable_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_brandTable_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5194);
/* harmony import */ var _pages_seller_components_AddNewHeaderInMainBoard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(956);
/* harmony import */ var _pages_manager_components_CustomToast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7073);
/* harmony import */ var _pages_manager_components_AddButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7776);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const SubCategoryMainBoard = ()=>{
    const [subCategory, setSubCategory] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [searchItem, setSearchItem] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [formShow, setFormShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [subCatName, setSubCatName] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [toastShow, setToastShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const fetchSubCategoryList = async ()=>{
        const allSubCategory = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_3__/* .getSubCategoryList */ .Yj)();
        setSubCategory(allSubCategory);
    };
    const searchOption = (event)=>{
        const searchValue = event.target.value;
        setSearchItem(searchValue);
        if (searchValue.length > 0) {
            const filteredSubCategory = subCategory.filter((cat)=>cat.name.toLowerCase().includes(searchValue.toLowerCase()));
            setSubCategory(filteredSubCategory);
        } else {
            fetchSubCategoryList().then((r)=>true);
        }
    };
    const onHandleShowForm = ()=>{
        setFormShow(!formShow);
    };
    function showToast() {
        setToastShow(!toastShow);
        setTimeout(()=>{
            setToastShow(false);
        }, 3000);
    }
    const onHandleAddNew = ()=>{
        const brandData = {
            name: subCatName // Replace 'New Brand' with the desired brand name
        };
        fetch("https://seba-backend.xyz/api-admin/create-subcategories/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + localStorage.getItem("access_token") // Replace YOUR_TOKEN_HERE with the actual bearer token
            },
            body: JSON.stringify(brandData)
        }).then((response)=>response.json()).then((data)=>{
            console.log(data);
            showToast();
            onHandleShowForm();
            fetchSubCategoryList().then((r)=>true);
        }).catch((error)=>{
            console.error("Error creating brand:", error);
        // Handle the error
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchSubCategoryList().then((r)=>true);
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            toastShow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_manager_components_CustomToast__WEBPACK_IMPORTED_MODULE_5__["default"], {
                message: "Successfully Added!"
            }) : "",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_AddNewHeaderInMainBoard__WEBPACK_IMPORTED_MODULE_4__["default"], {
                header6Text: "List of Sub Category",
                header4Text: "Specialized List",
                addingThing: "Add new sub-category",
                onHandleShowForm: onHandleShowForm
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                style: formShow ? {
                    display: "block",
                    marginBottom: "20px"
                } : {
                    display: "none"
                },
                id: "subCategoryFormID",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                children: "Add New"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-10",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "Sub Category",
                                            value: subCatName,
                                            onChange: (e)=>setSubCatName(e.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-md-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_manager_components_AddButton__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                            buttonName: "Add",
                                            onHandleAddNew: onHandleAddNew
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row mb-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-8"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-md-4 " + (_styles_BrandsPage_module_css__WEBPACK_IMPORTED_MODULE_7___default().extraWork)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    value: searchItem,
                                    onChange: searchOption,
                                    className: "form-control w-50 mb-3",
                                    placeholder: "search "
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "card " + (_styles_brandTable_module_css__WEBPACK_IMPORTED_MODULE_8___default().cardBackground),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "card-body",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                className: "card-title mb-4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                    children: "All Sub-Category"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mt-3",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                    className: (_styles_brandTable_module_css__WEBPACK_IMPORTED_MODULE_8___default().table),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                        scope: "col",
                                                                        children: "S.N."
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                        scope: "col",
                                                                        children: "Specialized For"
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                            children: subCategory.length > 0 ? subCategory.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            "data-label": "Quantity Left",
                                                                            children: index + 1
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            "data-label": "Quantity Left",
                                                                            children: item.name
                                                                        })
                                                                    ]
                                                                }, item.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {})
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubCategoryMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;