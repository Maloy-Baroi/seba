exports.id = 9081;
exports.ids = [9081];
exports.modules = {

/***/ 9561:
/***/ ((module) => {

// Exports
module.exports = {
	"label": "profileFormInputComp_label__st_6d",
	"mandatory": "profileFormInputComp_mandatory__lZp61",
	"notMandatory": "profileFormInputComp_notMandatory__adBE8",
	"input": "profileFormInputComp_input__cXAiz",
	"imageUpload": "profileFormInputComp_imageUpload__NeSJ3",
	"fileInput": "profileFormInputComp_fileInput__hkJGR",
	"imageUploads": "profileFormInputComp_imageUploads__gXUjO",
	"btnSubmit": "profileFormInputComp_btnSubmit__6FMkL",
	"btnCancel": "profileFormInputComp_btnCancel__4EzLQ"
};


/***/ }),

/***/ 9081:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_ProfileFormInputComp)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/styles/profileFormInputComp.module.css
var profileFormInputComp_module = __webpack_require__(9561);
var profileFormInputComp_module_default = /*#__PURE__*/__webpack_require__.n(profileFormInputComp_module);
;// CONCATENATED MODULE: ./src/assets/image/upload_file.svg
/* harmony default export */ const upload_file = ({"src":"/_next/static/media/upload_file.3f1e2709.svg","height":41,"width":41,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/pages/seller/components/ProfileFormInputComp.js





const ProfileFormInputComp = ({ inputValue , labelText , inputType , placeholderText , requiredPositive , disablePositive , onInputChange  })=>{
    const [previewImage, setPreviewImage] = (0,external_react_.useState)(null); // State to store the preview image URL
    const handleChange = (event)=>{
        if (inputType === "text") {
            onInputChange(event.target.value);
        } else if (inputType === "file") {
            const file = event.target.files[0];
            if (file) {
                const imageURL = URL.createObjectURL(file);
                setPreviewImage(imageURL); // Set the preview image URL
            } else {
                setPreviewImage(null); // Clear the preview image
            }
            onInputChange(file);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "form-group",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("label", {
                className: (profileFormInputComp_module_default()).label,
                children: [
                    labelText,
                    " \xa0",
                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                        className: requiredPositive ? (profileFormInputComp_module_default()).mandatory : (profileFormInputComp_module_default()).notMandatory,
                        children: "*"
                    })
                ]
            }),
            inputType === "text" && /*#__PURE__*/ jsx_runtime.jsx("input", {
                className: (profileFormInputComp_module_default()).input,
                type: inputType,
                placeholder: placeholderText,
                disabled: disablePositive,
                value: inputValue,
                onChange: handleChange
            }),
            inputType === "file" && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: (profileFormInputComp_module_default()).imageUpload,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("input", {
                        className: (profileFormInputComp_module_default()).fileInput,
                        type: inputType,
                        placeholder: placeholderText,
                        disabled: disablePositive,
                        onChange: handleChange
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: (profileFormInputComp_module_default()).imageUploads,
                        children: previewImage ? /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                            className: (profileFormInputComp_module_default()).previewImage,
                            src: previewImage,
                            alt: "Preview",
                            style: {
                                width: "200px",
                                height: "100px"
                            }
                        }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                    className: "fa fa-upload",
                                    "aria-hidden": "true"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("h4", {
                                    children: "Click to upload"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_ProfileFormInputComp = (ProfileFormInputComp);


/***/ })

};
;