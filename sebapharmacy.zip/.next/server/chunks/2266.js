"use strict";
exports.id = 2266;
exports.ids = [2266];
exports.modules = {

/***/ 8181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/excel.2e1e6895.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 8789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pdf.da3a374d.svg","height":20,"width":16,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 3948:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/printer.fac0d780.svg","height":20,"width":20,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 2266:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2104);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_icons_pdf_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8789);
/* harmony import */ var _assets_icons_excel_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8181);
/* harmony import */ var _assets_icons_printer_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3948);
/* harmony import */ var _pages_seller_components_ProductsTable__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1572);
/* harmony import */ var _pages_seller_components_SellerProfileForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6409);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_seller_components_ProductsTable__WEBPACK_IMPORTED_MODULE_6__, _pages_seller_components_SellerProfileForm__WEBPACK_IMPORTED_MODULE_7__]);
([_pages_seller_components_ProductsTable__WEBPACK_IMPORTED_MODULE_6__, _pages_seller_components_SellerProfileForm__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const SettingsMainBoard = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_MainboardHead__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    h4Text: "Settings",
                    h6Text: "Manage your profile"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card",
                    style: {
                        width: "100%",
                        marginLeft: "10px"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "card-body",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_seller_components_SellerProfileForm__WEBPACK_IMPORTED_MODULE_7__["default"], {})
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingsMainBoard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;