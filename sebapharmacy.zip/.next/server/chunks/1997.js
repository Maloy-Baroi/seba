"use strict";
exports.id = 1997;
exports.ids = [1997];
exports.modules = {

/***/ 1997:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5194);
/* harmony import */ var _styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(871);
/* harmony import */ var _styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__]);
_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const CreateMedicineForm = ()=>{
    const [p_name, setPName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [p_type, setPType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [strength, setStrength] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [allConsumptionType, setAllConsumptionType] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [purchased_quantity, setPurchasedQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [minimumQuantity, setMinimumQuantity] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [minimumPrice, setMinimumPrice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [buyingPrice, setBuyingPrice] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [expiry_date, setExpiryDate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [shelfNumber, setShelfNumber] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [description_, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [productNames, setProductNames] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [subCategories, setSubCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [allBrand, setBrand] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [allShelf, setAllShelf] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [categorySearchText, setCategorySearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [subCategorySearchText, setSubCategorySearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [brandSearchText, setBrandSearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [imported, setImported] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [importer, setImporter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const navigator = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchProductNames = async ()=>{
            const allProducts = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getMedicineInfoList */ .MT)();
            console.log("All Products", allProducts);
            setProductNames(allProducts);
        };
        const fetchCategories = async ()=>{
            const allCategories = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getCategoryList */ .AT)();
            setCategories(allCategories);
        };
        const fetchSubCategories = async ()=>{
            const allSubCategories = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getSubCategoryList */ .Yj)();
            setSubCategories(allSubCategories);
        };
        const fetchBrands = async ()=>{
            const allBrands = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getBrandList */ .Si)();
            setBrand(allBrands);
        };
        const fetchShelves = async ()=>{
            const allShelves = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getShelfList */ .OP)();
            setAllShelf(allShelves);
        };
        const fetchConsumptionType = async ()=>{
            const allTypeOfConsumption = await (0,_pages_api_app_data__WEBPACK_IMPORTED_MODULE_2__/* .getConsumptionTypeList */ .vG)();
            setAllConsumptionType(allTypeOfConsumption);
        };
        fetchProductNames().then((r)=>true);
        fetchCategories().then((r)=>true);
        fetchSubCategories().then((r)=>true);
        fetchBrands().then((r)=>true);
        fetchShelves().then((r)=>{
            console.log(allShelf);
        });
        fetchConsumptionType().then((r)=>true);
    });
    const filteredProductName = productNames.length > 0 ? productNames.filter((prod)=>{
        return prod.product_name.toLowerCase().startsWith(p_name.toLowerCase());
    }) : [];
    const filteredCategories = categories.length > 0 ? categories.filter((category)=>{
        return category.name.toLowerCase().startsWith(categorySearchText.toLowerCase());
    }) : [];
    const filteredSubCategories = subCategories.length > 0 ? subCategories.filter((category)=>{
        return category.name.toLowerCase().startsWith(subCategorySearchText.toLowerCase());
    }) : [];
    const filteredBrand = allBrand.length > 0 ? allBrand.filter((category)=>{
        return category.name.toLowerCase().startsWith(brandSearchText.toLowerCase());
    }) : [];
    const handleProductNameInputChange = (event)=>{
        let prodName = document.getElementById("productNamesID");
        prodName.style.display = "block";
        setPName(event.target.value);
        let specialisedForID = document.getElementById("specialisedForID");
        p_name.length > 0 ? specialisedForID.style.display = "block" : specialisedForID.style.display = "none";
    };
    const handleProductNameSelect = (productName, productStrength, productType, productGen, productCom)=>{
        setPName(productName);
        setStrength(productStrength);
        setPType(productType);
        setCategorySearchText(productGen);
        setBrandSearchText(productCom);
        let prodName = document.getElementById("productNamesID");
        prodName.style.display = "none";
    };
    const handleCategoryInputChange = (event)=>{
        let generics = document.getElementById("genericID");
        generics.style.display = "block";
        setCategorySearchText(event.target.value);
    };
    const handleCategorySelect = (categoryName)=>{
        setCategorySearchText(categoryName);
        let generics = document.getElementById("genericID");
        generics.style.display = "none";
    };
    const handleSubCategoryInputChange = (event)=>{
        let specialisedForID = document.getElementById("specialisedForID");
        specialisedForID.style.display = "block";
        setSubCategorySearchText(event.target.value);
    };
    const handleSubCategorySelect = (sub_categoryName)=>{
        setSubCategorySearchText(sub_categoryName);
        let specialisedForID = document.getElementById("specialisedForID");
        specialisedForID.style.display = "none";
    };
    const handleBrandInputChange = (event)=>{
        let brandID = document.getElementById("brandID");
        brandID.style.display = "block";
        setBrandSearchText(event.target.value);
    };
    const handleBrandSelect = (brandName)=>{
        setBrandSearchText(brandName);
        let brandForID = document.getElementById("brandID");
        brandForID.style.display = "none";
    };
    const onHandleSubmitForm = (e)=>{
        e.preventDefault();
        // const formData = new FormData(e.target)
        const requestBody = {
            barcode_id: 1001,
            name: p_name,
            type: p_type,
            unit: strength,
            quantity: purchased_quantity,
            minimum_alert_quantity: minimumQuantity,
            minimum_selling_price: minimumPrice,
            expiry_date: expiry_date.toString(),
            shelf: shelfNumber,
            status: status,
            category: categorySearchText,
            sub_category: subCategorySearchText,
            brand: brandSearchText,
            bought_price: buyingPrice,
            description: description_ ? description_ : "No details",
            is_medicine: true
        };
        if (imported) {
            requestBody.importer = importer;
            requestBody.imported = true;
        }
        fetch("https://seba-backend.xyz/api-product/products/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${localStorage.getItem("access_token")}`
            },
            body: JSON.stringify(requestBody)
        }).then((response)=>response.json()).then((data)=>// eslint-disable-next-line react-hooks/exhaustive-deps
            navigator.push("/seller/products")).catch((error)=>console.error(error));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "card",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "card-body",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                                children: "Add Medicine"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Medicine Name*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: p_name ? p_name : "",
                                            onChange: handleProductNameInputChange,
                                            placeholder: "Medicine Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            id: "productNamesID",
                                            style: p_name.length > 0 ? {
                                                display: "block",
                                                height: "200px",
                                                overflow: "scroll"
                                            } : {
                                                display: "none"
                                            },
                                            children: filteredProductName && filteredProductName.length > 0 ? filteredProductName.map((prodName)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    onClick: ()=>handleProductNameSelect(prodName.product_name, prodName.strength, prodName.type, prodName.generics, prodName.company),
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: [
                                                        prodName.product_name,
                                                        " (",
                                                        prodName.strength,
                                                        ")"
                                                    ]
                                                }, prodName.id)) : ""
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Generic Name*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: categorySearchText,
                                            onChange: handleCategoryInputChange,
                                            placeholder: "Generic Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            id: "genericID",
                                            style: categorySearchText.length > 0 ? {
                                                display: "block",
                                                height: "200px",
                                                overflow: "scroll"
                                            } : {
                                                display: "none"
                                            },
                                            children: filteredCategories && filteredCategories.length > 0 ? filteredCategories.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    onClick: ()=>handleCategorySelect(category.name),
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: category.name
                                                }, category.id)) : ""
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Medicine For*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: subCategorySearchText,
                                            onChange: handleSubCategoryInputChange,
                                            placeholder: "Specialised"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            id: "specialisedForID",
                                            style: subCategorySearchText.length > 0 ? {
                                                display: "block",
                                                height: "200px",
                                                overflowY: "auto",
                                                overflowX: "hidden"
                                            } : {
                                                display: "none"
                                            },
                                            children: filteredSubCategories && filteredSubCategories.length > 0 ? filteredSubCategories.map((sub_category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    onClick: ()=>handleSubCategorySelect(sub_category.name),
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: sub_category.name
                                                }, sub_category.id)) : ""
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-3",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Brand Name*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: brandSearchText,
                                            onChange: handleBrandInputChange,
                                            placeholder: "Brand"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            id: "brandID",
                                            style: brandSearchText.length > 0 ? {
                                                display: "block",
                                                height: "200px",
                                                overflowY: "auto",
                                                overflowX: "hidden"
                                            } : {
                                                display: "none"
                                            },
                                            children: filteredBrand && filteredBrand.length > 0 ? filteredBrand.map((brand_)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    onClick: ()=>handleBrandSelect(brand_.name),
                                                    style: {
                                                        cursor: "pointer"
                                                    },
                                                    children: brand_.name
                                                }, brand_.id)) : ""
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Type*"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                            className: "form-control",
                                            placeholder: "table/capsule",
                                            value: p_type,
                                            onChange: (e)=>{
                                                setPType(e.target.value);
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    children: "Select type (capsule/table)"
                                                }),
                                                allConsumptionType && allConsumptionType.length > 0 ? allConsumptionType.map((item, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        children: item.type_name
                                                    }, index);
                                                }) : ""
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Strength*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            placeholder: "example: 250mg / 500mg",
                                            value: strength,
                                            onChange: (e)=>setStrength(e.target.value)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Quantity*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Quantity",
                                            value: purchased_quantity.toString(),
                                            onChange: (e)=>setPurchasedQuantity(parseInt(e.target.value))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Minimum Alert Qty*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Minimum Qty",
                                            value: minimumQuantity.toString(),
                                            onChange: (e)=>setMinimumQuantity(parseInt(e.target.value))
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Minimum Selling Price*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Price",
                                            min: "0.25",
                                            step: "0.01",
                                            value: minimumPrice.toString(),
                                            onChange: (e)=>setMinimumPrice(parseFloat(e.target.value))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Buying Price*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            className: "form-control",
                                            placeholder: "Price",
                                            min: "0.25",
                                            step: "0.01",
                                            value: buyingPrice.toString(),
                                            onChange: (e)=>setBuyingPrice(parseFloat(e.target.value))
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Expiry Date*"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "date",
                                            className: "form-control",
                                            value: expiry_date,
                                            onChange: (event)=>setExpiryDate(event.target.value)
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-lg-3 col-md-3 col-sm-6",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Shelf*"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                            className: "form-control",
                                            value: shelfNumber,
                                            onChange: (e)=>setShelfNumber(e.target.value),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    children: "select shelf"
                                                }),
                                                allShelf.length > 0 ? allShelf.map((shelf)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                                                        children: [
                                                            "Shelf: ",
                                                            shelf.number,
                                                            " Row: ",
                                                            shelf.row,
                                                            " Column: ",
                                                            shelf.column
                                                        ]
                                                    }, shelf.id)) : ""
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-lg-12 col-md-12 col-sm-12",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                        className: "form-control",
                                        value: description_,
                                        onChange: (e)=>setDescription(e.target.value)
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-md-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "checkbox",
                                        value: imported,
                                        onClick: (e)=>setImported(!imported)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "\xa0 Imported?"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-md-6",
                                children: imported && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().formGroup),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: "Importer"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control",
                                            value: importer,
                                            onChange: (event)=>setImporter(event.target.value)
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-12",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn me-2 " + (_styles_productForm_module_css__WEBPACK_IMPORTED_MODULE_4___default().btnSubmit),
                                onClick: onHandleSubmitForm,
                                children: "Submit"
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateMedicineForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;