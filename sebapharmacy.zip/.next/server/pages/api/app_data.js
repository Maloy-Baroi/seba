"use strict";
(() => {
var exports = {};
exports.id = 9500;
exports.ids = [9500,8240];
exports.modules = {

/***/ 2134:
/***/ ((module) => {

module.exports = import("isomorphic-unfetch");;

/***/ }),

/***/ 3944:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getAllOrders": () => (/* binding */ getAllOrders),
/* harmony export */   "getAlmostStockOutProducts": () => (/* binding */ getAlmostStockOutProducts),
/* harmony export */   "getBrandList": () => (/* binding */ getBrandList),
/* harmony export */   "getCategoryList": () => (/* binding */ getCategoryList),
/* harmony export */   "getConsumptionTypeList": () => (/* binding */ getConsumptionTypeList),
/* harmony export */   "getCustomerReport": () => (/* binding */ getCustomerReport),
/* harmony export */   "getCustomerSellerInvoiceCount": () => (/* binding */ getCustomerSellerInvoiceCount),
/* harmony export */   "getExpiredProductsList": () => (/* binding */ getExpiredProductsList),
/* harmony export */   "getImportedProducts": () => (/* binding */ getImportedProducts),
/* harmony export */   "getMedicineInfoList": () => (/* binding */ getMedicineInfoList),
/* harmony export */   "getMedicineList": () => (/* binding */ getMedicineList),
/* harmony export */   "getMonthSales": () => (/* binding */ getMonthSales),
/* harmony export */   "getMonthlyTotalSales": () => (/* binding */ getMonthlyTotalSales),
/* harmony export */   "getMostSoldProduct": () => (/* binding */ getMostSoldProduct),
/* harmony export */   "getNearToExpiredDate": () => (/* binding */ getNearToExpiredDate),
/* harmony export */   "getOrderListForLoginUser": () => (/* binding */ getOrderListForLoginUser),
/* harmony export */   "getPaymentMethodPercentage": () => (/* binding */ getPaymentMethodPercentage),
/* harmony export */   "getProductList": () => (/* binding */ getProductList),
/* harmony export */   "getProfileInfo": () => (/* binding */ getProfileInfo),
/* harmony export */   "getSellerList": () => (/* binding */ getSellerList),
/* harmony export */   "getShelfList": () => (/* binding */ getShelfList),
/* harmony export */   "getStockAlert": () => (/* binding */ getStockAlert),
/* harmony export */   "getSubCategoryList": () => (/* binding */ getSubCategoryList)
/* harmony export */ });
/* harmony import */ var _apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1300);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_apis__WEBPACK_IMPORTED_MODULE_0__]);
_apis__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// example.js

async function getMedicineList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/medicine-list/");
}
async function getProductList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/products-list/");
}
async function getMedicineInfoList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/medicines-info/");
}
async function getExpiredProductsList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/expired-products/");
}
async function getCategoryList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/categories/");
}
async function getOrderListForLoginUser() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/order-list/");
}
async function getAllOrders() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-admin/order-list-for-manager/");
}
async function getCustomerReport() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/customer-report");
}
async function getSubCategoryList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/sub-categories/");
}
async function getConsumptionTypeList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/product-consumption-types/");
}
async function getBrandList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/brand/");
}
async function getShelfList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/all-shelf/");
}
async function getStockAlert() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/stock-alerts/");
}
async function getNearToExpiredDate() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/near-expiry-products/");
}
async function getAlmostStockOutProducts() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/stock-less-than-minimum-quantity/");
}
async function getCustomerSellerInvoiceCount() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-admin/customer-seller-order-count/");
}
async function getSellerList() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-admin/seller-list/");
}
async function getProfileInfo() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/salesman-profile/");
}
async function getMonthSales() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/monthly-sales/");
}
async function getMonthlyTotalSales() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/order-stats/");
}
async function getPaymentMethodPercentage() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/payment-methods/");
}
async function getMostSoldProduct() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-seller/sold-products/");
}
async function getImportedProducts() {
    return await (0,_apis__WEBPACK_IMPORTED_MODULE_0__.callApi)("api-product/imported-products/");
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1300], () => (__webpack_exec__(3944)));
module.exports = __webpack_exports__;

})();