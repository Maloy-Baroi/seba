"use strict";
(() => {
var exports = {};
exports.id = 8240;
exports.ids = [8240];
exports.modules = {

/***/ 2134:
/***/ ((module) => {

module.exports = import("isomorphic-unfetch");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1300], () => (__webpack_exec__(1300)));
module.exports = __webpack_exports__;

})();