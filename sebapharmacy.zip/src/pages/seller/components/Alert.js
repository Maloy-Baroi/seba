const Alert = () => {
    return (
        <>
        </>
    );
}

export default Alert

